class Order{
  protected:
    char orderNumber[30];
    char orderDate[30];
    double price;
  
  public:
    void addOrderDetails(char number[], char date[], double price);
    void displayOrderDetails();
};