#include"Order.h"
#include<cstring>
#include<iostream>
using namespace std;

void Order::addOrderDetails(char number[], char date[], double Oprice){
  strcpy(orderNumber,number);
  strcpy(orderDate,date);
  price=Oprice;
}
void Order::displayOrderDetails(){
  cout<<"Order Number: "<<orderNumber<<endl;
  cout<<"Order Date: "<<orderDate<<endl;
  cout<<"Order Price: "<<price<<endl;
}